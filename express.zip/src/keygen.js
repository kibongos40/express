let key = require("keygen");

console.log(key.hex(64))