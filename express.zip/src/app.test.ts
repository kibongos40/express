import request,{ Request } from "supertest";
import app from "./app";
import dotenv from "dotenv"
import mongoose from "mongoose";

dotenv.config();

beforeAll(async()=>{
    mongoose.connect(process.env.MONGODB_URI as string);
})

afterAll(async()=>{
    mongoose.connection.close();
})

describe("Testing the root path", ()=>{
    test("Should respond Welcome", async()=>{
        let response = await request(app).get("/");
        expect(response.status).toBe(200);
        expect(response.body.message).toBe("Welcome");
    })
})

describe("Testing the blogs endpoint", () => {
	test("Should Return blogs", async () => {
        let response = await request(app).get("/blogs");
        expect(response.status).toBe(200);
        expect(response.body.status).toBe("success");
	});
});